package com.example.aula19102026

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
