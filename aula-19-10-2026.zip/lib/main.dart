import 'package:flutter/material.dart';

void main() {
  runApp(const ToDoListApp());
}

class ToDoListApp extends StatelessWidget {
  const ToDoListApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'To do List',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: false,
      ),
      home: const ToDoListPage(),
    );
  }
}

class Tarefa {
  Tarefa({required this.descricao, this.concluida = false});

  final String descricao;
  bool concluida;
}

class ToDoListPage extends StatefulWidget {
  const ToDoListPage({super.key});

  @override
  State<ToDoListPage> createState() => _ToDoListPageState();
}

class _ToDoListPageState extends State<ToDoListPage> {
  final TextEditingController _controller = TextEditingController();
  final List<Tarefa> _tarefas = [];

  void _cadastrarTarefa() {
    final descricao = _controller.text.trim();

    if (descricao.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Digite uma tarefa antes de cadastrar.'),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    setState(() {
      // Toda tarefa nova é inserida no começo da lista.
      _tarefas.insert(0, Tarefa(descricao: descricao));
      _controller.clear();
    });
  }

  void _alterarConclusao(int indice, bool? valor) {
    if (valor == null) return;

    setState(() {
      final tarefa = _tarefas.removeAt(indice);
      tarefa.concluida = valor;

      if (valor) {
        // Tarefa marcada: vai para o final da lista.
        _tarefas.add(tarefa);
      } else {
        // Tarefa desmarcada: volta para o começo da lista.
        _tarefas.insert(0, tarefa);
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('To do List'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _cadastrarTarefa(),
              decoration: const InputDecoration(
                hintText: 'Tarefa',
                prefixIcon: Icon(Icons.assignment),
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 38,
              child: ElevatedButton(
                onPressed: _cadastrarTarefa,
                child: const Text('Cadastrar'),
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _tarefas.isEmpty
                  ? const SizedBox.shrink()
                  : ListView.builder(
                      itemCount: _tarefas.length,
                      itemBuilder: (context, indice) {
                        final tarefa = _tarefas[indice];

                        return CheckboxListTile(
                          contentPadding:
                              const EdgeInsets.symmetric(horizontal: 4),
                          title: Text(
                            tarefa.descricao,
                            style: TextStyle(
                              decoration: tarefa.concluida
                                  ? TextDecoration.lineThrough
                                  : TextDecoration.none,
                            ),
                          ),
                          value: tarefa.concluida,
                          controlAffinity: ListTileControlAffinity.trailing,
                          dense: true,
                          onChanged: (valor) =>
                              _alterarConclusao(indice, valor),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
